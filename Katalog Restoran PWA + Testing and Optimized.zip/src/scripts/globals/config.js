const CONFIG = {
  BASE_URL: "https://restaurant-api.dicoding.dev",
  CACHE_NAME: "RESTaurant-V1",
  DATABASE_NAME: "RESTaurant_IDB",
  DATABASE_VERSION: 1,
  OBJECT_STORE_NAME: "Favorite",
};

export default CONFIG;
